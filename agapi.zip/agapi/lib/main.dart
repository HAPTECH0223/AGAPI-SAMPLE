import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// Replace with your actual OpenAI API key
const String OPENAI_API_KEY = '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';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Follow-Up Generator',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const FollowUpGeneratorPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class FollowUpGeneratorPage extends StatefulWidget {
  const FollowUpGeneratorPage({super.key});

  @override
  State<FollowUpGeneratorPage> createState() => _FollowUpGeneratorPageState();
}

class _FollowUpGeneratorPageState extends State<FollowUpGeneratorPage> {
  final TextEditingController _controller = TextEditingController();
  String _followUpQuestion = '';
  bool _isLoading = false;

  Future<void> _generateFollowUp() async {
    final String statement = _controller.text.trim();
    if (statement.isEmpty) return;

    setState(() {
      _isLoading = true;
      _followUpQuestion = '';
    });

    // Construct a prompt to instruct the AI
    final String prompt =
        'Generate a follow-up question for this statement: "$statement"';

    // Use the chat completions endpoint for chat models
    final url = Uri.parse('https://api.openai.com/v1/chat/completions');
    try {
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $OPENAI_API_KEY',
        },
        body: jsonEncode({
          'model': 'gpt-4o', // Ensure this model is valid for your use-case
          'messages': [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt},
          ],
          'max_tokens': 50,
          'temperature': 0.7,
        }),
      );

      // Print response details to the console
      print("Response status: ${response.statusCode}");
      print("Response body: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final generatedText = data['choices'][0]['message']['content'];
        setState(() {
          _followUpQuestion = generatedText.trim();
          _isLoading = false;
        });
      } else {
        // Log the error details and update UI with error information
        setState(() {
          _followUpQuestion =
          'Error generating follow-up question. Status: ${response.statusCode}, Details: ${response.body}';
          _isLoading = false;
        });
      }
    } catch (e, stacktrace) {
      // Log exception details
      print("Exception caught: $e");
      print("Stacktrace: $stacktrace");
      setState(() {
        _followUpQuestion = 'Error generating follow-up question. Exception: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // Use a ScrollView to ensure mobile friendliness on smaller screens.
    return Scaffold(
      appBar: AppBar(
        title: const Text('Follow-Up Generator'),
        centerTitle: true,
        elevation: 4.0,
      ),
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(), // dismiss keyboard
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
          child: Column(
            children: [
              Card(
                elevation: 4.0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.0)),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: TextField(
                    controller: _controller,
                    maxLines: null,
                    decoration: const InputDecoration(
                      hintText: 'Enter your statement here...',
                      border: InputBorder.none,
                    ),
                    style: const TextStyle(fontSize: 18.0),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _generateFollowUp,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 32.0, vertical: 16.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                    textStyle: const TextStyle(fontSize: 16),
                  ),
                  child: _isLoading
                      ? const SizedBox(
                    height: 24,
                    width: 24,
                    child: CircularProgressIndicator(
                      strokeWidth: 3,
                      color: Colors.white,
                    ),
                  )
                      : const Text('Generate Follow-Up'),
                ),
              ),
              const SizedBox(height: 30),
              if (_followUpQuestion.isNotEmpty) ...[
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Your Statement:',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium!
                        .copyWith(fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                  child: Text(
                    _controller.text,
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
                const SizedBox(height: 20),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Follow-Up Question:',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium!
                        .copyWith(fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                  child: Text(
                    _followUpQuestion,
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              ]
            ],
          ),
        ),
      ),
    );
  }
}
