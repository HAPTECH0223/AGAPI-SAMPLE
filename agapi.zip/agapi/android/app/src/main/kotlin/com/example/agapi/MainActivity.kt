package com.example.agapi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
